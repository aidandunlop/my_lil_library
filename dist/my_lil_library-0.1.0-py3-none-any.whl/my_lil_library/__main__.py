def main():
    print("Hello from my lil library!")


if __name__ == "__main__":
    main()
