import numpy as np


def function_one():
    print("hi from function one")
    return "a string"


def function_two():
    print("hi from function two")
    return "another string"


def function_three():
    a_variable = np.float("0.3")
    return a_variable
